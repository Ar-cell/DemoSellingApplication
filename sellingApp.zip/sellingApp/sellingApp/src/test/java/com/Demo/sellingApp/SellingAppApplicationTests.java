package com.Demo.sellingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
