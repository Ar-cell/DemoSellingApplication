package com.Demo.sellingApp.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Demo.sellingApp.config.Response;
import com.Demo.sellingApp.dto.ClientMasterDto;
import com.Demo.sellingApp.dto.ProductMasterDto;
import com.Demo.sellingApp.entity.ClientMaster;
import com.Demo.sellingApp.entity.ProductMaster;

@Service
public interface ClientMasterService {
	
	Response saveClients(ClientMasterDto clientmasterDto);
	
	Response saveProductMaster(ProductMasterDto productMasterDto);
	
	
	List<ClientMasterDto> fetchClientMasterList();
	
	List<ProductMasterDto> fetchProductMasterList();
	
	void remove(Integer id);
	
	ResponseEntity<String> updateClientMaster(ClientMasterDto clientmasterDto );
	
	ResponseEntity<String> updateProductMaster(ProductMasterDto productMasterDto);

}
